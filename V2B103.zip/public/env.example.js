window.v2board = {
  // 站点标题
  title: 'V2Board',
  // API
  host: '',
  // 主题
  theme: '1',
  // 背景
  background_url: ''
}
