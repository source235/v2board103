<?php

namespace App\Http\Controllers\Passport;

use App\Http\Requests\Passport\RegisterIndex;
use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Plan;
use Illuminate\Support\Facades\Cache;
use App\Utils\Helper;
use App\Models\InviteCode;

class RegisterController extends Controller
{
    private function setTryOut()
    {

    }

    public function index(RegisterIndex $request)
    {
        if ((int)config('v2board.stop_register', 0)) {
            abort(500, '本站已关闭注册');
        }
        if ((int)config('v2board.invite_force', 0)) {
            if (empty($request->input('invite_code'))) {
                abort(500, '必须使用邀请码才可以注册');
            }
        }
        if ((int)config('v2board.email_verify', 0)) {
            $redisKey = 'sendEmailVerify:' . $request->input('email');
            if (empty($request->input('email_code'))) {
                abort(500, '邮箱验证码不能为空');
            }
            if (Cache::get($redisKey) !== $request->input('email_code')) {
                abort(500, '邮箱验证码有误');
            }
        }
        $email = $request->input('email');
        $password = $request->input('password');
        $exist = User::where('email', $email)->first();
        if ($exist) {
            abort(500, '邮箱已存在系统中');
        }
        $user = new User();
        $user->email = $email;
        $user->password = password_hash($password, PASSWORD_DEFAULT);
        $user->v2ray_uuid = Helper::guid(true);
        $user->token = Helper::guid();
        if ($request->input('invite_code')) {
            $inviteCode = InviteCode::where('code', $request->input('invite_code'))
                ->where('status', 0)
                ->first();
            if (!$inviteCode) {
                if ((int)config('v2board.invite_force', 0)) {
                    abort(500, '邀请码无效');
                }
            } else {
                $user->invite_user_id = $inviteCode->user_id ? $inviteCode->user_id : null;
                if (!(int)config('v2board.invite_never_expire', env('V2BOARD_INVITE_NEVER_EXPIRE'))) {
                    $inviteCode->status = 1;
                    $inviteCode->save();
                }
            }
        }

        // try out
        if ((int)config('v2board.try_out_enable', 0)) {
            $plan = Plan::find(config('v2board.try_out_plan_id'));
            if ($plan) {
                $user->transfer_enable = $plan->transfer_enable * 1073741824;
                $user->plan_id = $plan->id;
                $user->group_id = $plan->group_id;
                $user->expired_at = time() + (config('v2board.try_out_hour', 1) * 3600);
            }
        }

        if (!$user->save()) {
            abort(500, '注册失败');
        }
        if ((int)config('v2board.email_verify', 0)) {
            Cache::forget($redisKey);
        }
        return response()->json([
            'data' => true
        ]);
    }
}
