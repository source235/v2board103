<?php

namespace App\Utils;

class CacheKey
{

}
